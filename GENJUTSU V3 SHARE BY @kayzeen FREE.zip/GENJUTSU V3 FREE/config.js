require("./all/module")


global.storename = "Kaizi Market"
global.dana = "6287776455065"
global.gopay = "6283137625080"
global.qris = false
global.owner = "KaiziXyz"
global.namabot = "Genjutsu"
global.nomorbot = "6283137625080"
global.namaCreator = "Kaizi Market"
global.linkyt = ""
global.autoJoin = false
global.antilink = false
global.versisc = '3.0'
global.delayjpm = 5500
global.codeInvite = ""
global.imageurl = 'https://files.catbox.moe/7stqph.jpg'
global.isLink = 'https://whatsapp.com/channel/0029VarfIUD29756w9y0Gu0x'
global.packname = "Sticker By🐉"
global.author = "KAIZI - \n\n\n\n\n\n62857242698411"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})